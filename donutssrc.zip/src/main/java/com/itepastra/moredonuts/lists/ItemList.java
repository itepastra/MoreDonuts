package com.itepastra.moredonuts.lists;

import net.minecraft.item.Item;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemGroup;

public class ItemList {
    public static Item stone_donut = new ItemFood(1,1.0f,false, new Item.Properties().maxStackSize(6).group(ItemGroup.FOOD)).setRegistryName("stone_donut");
    public static Item coal_donut = new ItemFood(2,2.0f,false, new Item.Properties().maxStackSize(12).group(ItemGroup.FOOD)).setRegistryName("coal_donut");
    public static Item iron_donut = new ItemFood(4,4.0f,false, new Item.Properties().maxStackSize(12).group(ItemGroup.FOOD)).setRegistryName("iron_donut");
    public static Item gold_donut = new ItemFood(8,8.0f,false, new Item.Properties().maxStackSize(12).group(ItemGroup.FOOD)).setRegistryName("gold_donut");
    public static Item diamond_donut = new ItemFood(16,16.0f,false, new Item.Properties().maxStackSize(12).group(ItemGroup.FOOD)).setRegistryName("diamond_donut");
    public static Item emerald_donut = new ItemFood(20,44.0f,false, new Item.Properties().maxStackSize(12).group(ItemGroup.FOOD)).setRegistryName("emerald_donut");
    public static Item the_ultimate_donut = new ItemFood(20,300000.0f,false, new Item.Properties().maxStackSize(12).group(ItemGroup.FOOD)).setRegistryName("the_ultimate_donut");
}
